<?php
session_start();
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "tcc";
//Efetua a conexão com o BD
$link = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname) or die('Error connecting to MySQL Server.');
?>

<!DOCTYPE html>
<html>
    <head>
      <link rel= "stylesheet" type="text/css" href="sobre.css" />
      <meta charset="utf-8">
     <title> VetPlus </title>
    </head>
    
<body>

   <header class="topo">
   </header>    <!--dentro do cabeçalho-->

<!--menu de opçoes-->          
 <nav id="menu">
    <ul>
    <b>
        <li><a href="sobre.php"> Sobre nós</a></li>
        <li><a href="home.php"> Home</a></li>
        <li><a href="home.php"> Fale conosco </a></li>
    <b>
    </ul>
</nav>    
    
<div class="baixo"> <!--fundo do site todo-->
<div class="conteudo"> <!--conteudo que contem as duas caixas-->



<p> 



<br/>

<br/>

    QUEM SOMOS?
<br/>

<br/>
<br/>


A VetPlus Clínica Veterinária nasceu em março de 2022 com o compromisso de oferecer a toda Vila Nova e região atendimento diferenciado e completo a cães e gatos. Temos tudo para atendimento veterinário em um só lugar, você não precisa se deslocar para nada.
Nossa assistência é de modo inteiramente individualizado desde a recepção até a internação, unindo seriedade, técnica e medicina com outros aspectos da vida capazes do reconforto, da descontração e de uma verdadeira sensação de acolhimento como merece cada espécie!
O Amor que colocamos em cada tarefa é o que transforma o nosso trabalho em uma MISSÃO DE VIDA. Com dedicação exclusiva para cada tutor e cada paciente, colocando a saúde daquele que só nos dá amor em primeiro lugar, com muita ética, respeito e comprometimento.
Venha nos conhecer!

</h2> 
</p>
<br/>


<br/>
<br/>
<br/>
<br/>
<br/>




<br /> <!--serve para pular linha-->


<br/>
<br/>


<footer class="rodape">



     <p>  <b> Copyright@ 2022 - Desenvolvido por Aline Luiza, Letícia Nurnberg e Naiély Cabral </p>

      </footer>

 </body>
</html>