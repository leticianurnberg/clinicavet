
<?php
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
      <link rel= "stylesheet" type="text/css" href="login.css"/>
      <meta charset="utf-8">
     <title> VetPlus </title>
    </head>
    
<body>

   <header class="topo">
   </header>    <!--dentro do cabeçalho-->

<!--menu de opçoes-->          
 <nav id="menu">
    <ul>
    <b>
        <li><a href="sobre.php"> Sobre nós</a></li>
        <li><a href="home.php"> Home</a></li>
        <li><a href="home.php"> Fale conosco </a></li>
       <b>
       
    </ul>
</nav>    
    
<div class="baixo"> <!--fundo do site todo-->
<div class="conteudo"> <!--conteudo que contem as duas caixas-->

<!--caixa esquerda-->
<div class="boxum"> 




<form method="POST" action="valida.php">


   <fieldset id="usuario" style="font-size: 36px;"> <legend> </legend>
      

      <p>E-mail: <input type="e-mail" name="tMail" id="cMail"
                size="40" maxlength="40" placeholder=" ex: email@com.br"
                type="cMail" required />  </p>


  <p> Senha: <input type="password" name="tSenha" id="cSenha" 
               size="40" maxlength="8" pattern="[a-zA-Z0-9]+" 
               title="Usar números e letras somente" placeholder="8 dígitos" /> </p>

<br/> 

<input type="submit"  name= "botao" value=" Entrar " />

<br/>

    </fieldset>

       

   </form>


<nav id="cadastro">
    <ul>
        <li><a href="cadastro.php"> <b> Não tem um cadastro? cadastre-se <b> </a></li>
       
    </ul>
</nav>    




<br />
<br />
<br />
<br />
<br />
<br />





<footer class="rodape">

     <p> <b> Copyright@ 2022 - Desenvolvido por Aline Luiza, Letícia Nurnberg e Naiély Cabral </p>

      </footer>

 </body>
</html>