<?php
//Conectar–se ao BD
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "tcc";


//Efetua a conexão com o BD
$link = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname) or die('Error connecting to MySQL Server.');

?>

<!DOCTYPE html>
<html>
    <head>
      <link rel= "stylesheet" type="text/css" href="cadastro.css" />
      <meta charset="utf-8">
     <title> VetPlus </title>
    </head>
    
<body>

   <header class="topo">
   </header>    <!--dentro do cabeçalho-->

<!--menu de opçoes-->          
 <nav id="menu">
    <ul>
    <b>
        <li><a href="sobre.php"> Sobre nós</a></li>
        <li><a href="home.php"> Home</a></li>
        <li><a href="home.php"> Fale conosco </a></li>
        <b>
    </ul>
</nav>    
    
<div class="baixo"> <!--fundo do site todo-->
<div class="conteudo"> <!--conteudo que contem as duas caixas-->




<form action="process_form.php" method="post">
   <fieldset id="user"> <legend> </legend>
    

    <label>Nome: </label> 
    <input type="text" name="nome" placeholder="" size="40"> <br><br>

    <label> Raça: </label> 
    <input type="text" name="nome" placeholder="" size="40"> <br><br>

    <label> Porte: </label> 
    <input type="text" name="nome" placeholder="" size="40"> <br><br>

    <label> Castrado? </label> 
    <input type="text" name="nome" placeholder="" size="40"> <br><br>

    <label> Vacinação em dia? </label> 
    <input type="text" name="nome" placeholder="" size="40"> <br><br>

    <label>Data de Nascimento:</label> 
    <input type="date" name="nasc"> <br><br>

    <label> Peso:</label> 
    <input type="int" name="telefone"  placeholder="" size="40"> <br><br>


<br>
<br/>


  <input type="submit" value="Realizar cadastro" /> 

<br/>


      </fieldset>
     
      
</form>


<nav id="cadastro">
    <ul>
        <li><a href="login.php"> <b> Já tem um cadastro? entrar <b> </a></li>
       
    </ul>
</nav>    






<br/>


<footer class="rodape">



     <p>  <b> Copyright@ 2022 - Desenvolvido por Aline Luiza, Letícia Nurnberg e Naiély Cabral </p>

      </footer>

 </body>
</html>