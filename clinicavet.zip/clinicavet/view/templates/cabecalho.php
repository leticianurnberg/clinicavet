<html lang="pt-BR">

<head>

    <title>Easy Games</title>

    <meta charset="utf-8">

    <link rel="stylesheet" type="text/css" href="../semantic/semantic.css">

    <script type="text/javascript" src="semantic/semantic.min.js"></script>
    <script type="text/javascript" src="ckeditor/ckeditor.js"></script>

</head>

<body style="background-color: #2B2B2B">

<div class="ui top attached tabular inverted menu" style= "height:5.5%;background-color: #191919; ">

    <div class="ui medium image" style=" margin-left: 3%">
        <img src="../imagenseg/Easy Gaming.png">
    </div>
    <div class="right menu">
        <a class="item" href="indexAdmin.html">
            Home
        </a>

        <a class="item active" href="exibe_noticia.php">
            Noticias
        </a>

        <a class="item" href="avalia.html">
            Avaliações
        </a>
    </div>


    <div class="right menu">

        <div class="right menu">

            <a class="item" href="login.html">
                <i class="user icon"></i>
                Logout
            </a>
        </div>

        <div class="item">

            <div class="ui transparent icon input">
                <input type="text" placeholder="Pesquisar...">
                <i class="search link icon"></i>


            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function Nova()
    {
        location.href="exibe_avaliacao.php"
    }
</script>
</html>