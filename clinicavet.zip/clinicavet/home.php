<?php
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
      <link rel= "stylesheet" type="text/css" href="homenovo.css" />

      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <link rel="stylesheet" type="text/css" href="">

    <script type="text/javascript" src="semantic/semantic.min.js"></script>

     <title> Vetplus </title>

    </head>
    
<body>


   <header class="topo">
   </header>    <!--dentro do cabeçalho-->

<!--menu de opçoes-->          
 <nav id="menu">
    <ul> <b>
        <li><a href="sobre.php"> Sobre nós</a></li>
        <li><a href="home.php"> Home</a></li>
        <li><a href="home.php"> Fale conosco </a></li>
        <li><a href="login.php"> Login </a></li>
        <b>
    </ul>
</nav>    
    
<div class="baixo"> <!--fundo do site todo-->
<div class="conteudo"> <!--conteudo que contem as duas caixas-->

<!--caixa esquerda-->
<div class="boxum"> 

<br /> <!--serve para pular linha-->



  </p>


<div class="ui segment" style=" background-color: #191919;margin-top: 0%">



        <!-- bxSlider CSS file -->
        <link href="slider/jquery.bxslider.css" rel="stylesheet" />

        <ul class="bxslider" style="background-color: #113445">
         
          <li><img src="slider/images/1.png" style="width: 100%" /></li>
          <li><img src="slider/images/2.png" style="width: 100%" /></li>
          <li><img src="slider/images/3.png" style="width: 100%" /></li>
        </ul>

        <!-- jQuery library -->
        <script src="slider/jquery-3.1.1.min.js"></script>
        <!-- bxSlider Javascript file -->
        <script src="slider/jquery.bxslider.js"></script>
        <script>
          $(document).ready(function(){
            $('.bxslider').bxSlider({
              mode: 'horizontal',
              moveSlides: 1,
              slideMargin: 0,
              infiniteLoop: true,
              minSlides: 1,
              maxSlides: 1,
              speed: 100,
              auto: true,
              responsive: true
            });
          });
        </script>

      </div>

      <h2> Serviços Prestados </h2>



      </div>



<br/>






<div class="conteudogaleria">

    <div class="boxleft"> <!--Box da esquerda-->

      <div class="galeria">
        <a target="_blank" href="home.php"> <img src="img/tosa.png" alt="PET SHOP"> </a> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
        <div class="desc"> Pet Shop </div>

    </div>
    </div>

    <!--==============================================================================================================================-->

    <div class="boxcenter"> <!--Box do centro-->

      <div class="galeria">
        <a target="_blank" href="home.php"> <img src="img/consulta.png" alt="CONSULTA"> </a> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
        <div class="desc"> Consulta </div>
      </div>
      </div>


     

    <!--==============================================================================================================================-->

    <div class="boxright"> <!--Box da direita-->

      <div class="galeria">
        <a target="_blank" href="home.php"> <img src="img/cirurgia.png" alt=" Eucaristia "></a> &nbsp &nbsp &nbsp &nbsp &nbsp 
        <div class="desc"> Cirurgia </div>
      </div>  
      </div>


    <div class="box"> <!--Box da -->

      <div class="galeria">
        <a target="_blank" href="home.php"> <img src="img/vacina.png" alt=" VACINA "></a> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
        <div class="desc"> Vacina </div>
      </div>
      </div>




</div> <!--aqui fecha o box1-->



<br />
<br />
<br />
<br />
<br />
<br />
<br />



  </p>


<footer class="rodape">



     <p> Copyright@ 2022 - Desenvolvido por Aline Luiza, Letícia Nurnberg e Naiély Cabral </p>

      </footer>

 </body>
</html>