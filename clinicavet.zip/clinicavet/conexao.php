<?php

$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "tcc";


//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname) or die ('Não foi possível efetuar a conexão com o Banco de Dados');

?>