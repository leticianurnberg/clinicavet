<?php
//Conectar–se ao BD
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "tcc";


//Efetua a conexão com o BD
$link = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname) or die('Error connecting to MySQL Server.');

?>

<!DOCTYPE html>
<html>
    <head>
      <link rel= "stylesheet" type="text/css" href="cadastro.css" />
      <meta charset="utf-8">
     <title> VetPlus </title>
    </head>
    
<body>

   <header class="topo">
   </header>    <!--dentro do cabeçalho-->

<!--menu de opçoes-->          
 <nav id="menu">
    <ul>
    <b>
        <li><a href="sobre.php"> Sobre nós</a></li>
        <li><a href="home.php"> Home</a></li>
        <li><a href="home.php"> Fale conosco </a></li>
        <b>
    </ul>
</nav>    
    
<div class="baixo"> <!--fundo do site todo-->
<div class="conteudo"> <!--conteudo que contem as duas caixas-->



 
<br/>
<form action="process_form.php" method="post">
   <fieldset id="user"> <legend> </legend>
    

    
    <label>Nome Completo: </label> 
    <input type="text" name="nome" placeholder="Digite seu nome" size="40"> <br><br>

    <label> Endereço:</label> 
    <input type="text" name="endereço"  placeholder=" ex: Rua Amaro, n°48, bairro Frambuesa" size="40"> <br><br>

    <label> CPF: </label> 
    <input type="int" name="cpf" placeholder=" ex: 125.528.255-47" size="40"> <br><br>

    <label> Telefone:</label> 
    <input type="int" name="telefone"  placeholder=" ex:(44)4525-9658" size="40"> <br><br>

    <label> Senha: </label>
    <input type="password" name="senha" placeholder="8 dígitos" size="40"> <br><br>
    
    

<br><br>
<br/>


  <input type="submit" value="Realizar cadastro" /> 

<br/>


      </fieldset>
     
      
</form>


<nav id="cadastro">
    <ul>
        <li><a href="login.php"> <b> Já tem um cadastro? entrar <b> </a></li>
       
    </ul>
</nav>    



<br /> <!--serve para pular linha-->


<br/>
<br/>


<footer class="rodape">



     <p>  <b> Copyright@ 2022 - Desenvolvido por Aline Luiza, Letícia Nurnberg e Naiély Cabral </p>

      </footer>

 </body>
</html>